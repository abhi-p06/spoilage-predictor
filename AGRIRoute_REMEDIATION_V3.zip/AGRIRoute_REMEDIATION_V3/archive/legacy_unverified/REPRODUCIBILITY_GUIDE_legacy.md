# AgriRoute Reproducibility & Experimental Execution Guide

## 1. Experimental Environment & System Manifest

To guarantee absolute scientific reproducibility, all experiments conducted in the AgriRoute computer vision revision are executed under a version-pinned, seed-locked software and hardware configuration.

### System & Hardware Specifications:
- **Operating System:** Darwin / macOS 15.0+ (Apple Silicon Architecture)
- **Processor:** Apple M4 SoC (Hardware GPU acceleration via Metal PluggableDevice)
- **System Memory:** 16.00 GB Unified RAM (5.92 GB maximum cache allocation)
- **Python Runtime:** Python 3.11.15 (`/opt/miniconda3/envs/spoilage`)
- **Primary Framework:** TensorFlow 2.16.2 / Keras 3.14.1 with `tensorflow-metal`
- **Core Dependencies:**
  - `scikit-learn`: 1.9.0
  - `pillow`: 12.2.0
  - `imagehash`: 4.3.2
  - `opencv-python`: 4.12.0
  - `pandas`: 2.2.3
  - `numpy`: 1.26.4
  - `mlflow`: 2.20.2
  - `scipy`: 1.17.1

### Determinism & Random Seeds:
Random seeds are strictly set to `SEED = 42` across all four layers:
1. `os.environ["PYTHONHASHSEED"] = "42"`
2. `random.seed(42)`
3. `numpy.random.seed(42)`
4. `tf.random.set_seed(42)`
5. `os.environ["TF_DETERMINISTIC_OPS"] = "1"`

---

## 2. Dataset Partitions and Split Manifests

Data partitioning adheres strictly to the **Group-Aware Stratified Partitioning Protocol** defined in `DATASET_PROVENANCE.md`. Split manifests are permanently recorded in `experiments/split_manifests/`:

| Manifest File | Partition Role | Sample Count | Cluster / Group Key | Leakage Prevention Strategy |
| :--- | :--- | :---: | :--- | :--- |
| `train.csv` | Model Optimization | 19,032 | `base_subject_id` | Dynamic data augmentation only |
| `val.csv` | Model Selection & Early Stopping | 4,076 | `base_subject_id` | Un-augmented, zero-overlap with train |
| `test_internal.csv`| In-Distribution Evaluation | 4,090 | `base_subject_id` | Sealed test set, zero-overlap with train/val |
| `test_external.csv`| Zero-Shot Domain Generalization | 4,185 | Dataset Source (FruitVision) | Independent camera sensors & real retail market |

---

## 3. Step-by-Step Reproduction Pipeline

All experimental workflows are modular, configuration-driven, and scriptable via command-line arguments.

### Step 1: Forensic Audit and Data Partitioning
Scans raw archives, removes corrupt images, extracts base subject identifiers, computes MD5/pHash hashes, and generates split manifests:
```bash
python scripts/audit_and_split_datasets.py
```

### Step 2: Vision Backbone Benchmarking (Phase 3 & 4)
Trains and validates each vision backbone under identical two-phase protocols (frozen head training followed by top-layer fine-tuning with early stopping):
```bash
# MobileNetV2
python scripts/train_vision_benchmark.py --config experiments/configs/mobilenet_v2.yaml

# EfficientNetB0
python scripts/train_vision_benchmark.py --config experiments/configs/efficientnet_b0.yaml

# ResNet50
python scripts/train_vision_benchmark.py --config experiments/configs/resnet50.yaml
```

### Step 3: Comprehensive Multi-Class & Bootstrap Evaluation (Phase 4 & 5)
Computes Accuracy, Balanced Accuracy, Macro-F1, per-class F1, Confusion Matrices, ROC-AUC (OVR), PR-AUC, and 95% bootstrap confidence intervals ($B=1000$):
```bash
python scripts/evaluate_models.py --config experiments/configs/mobilenet_v2.yaml
python scripts/evaluate_models.py --config experiments/configs/efficientnet_b0.yaml
python scripts/evaluate_models.py --config experiments/configs/resnet50.yaml
```

### Step 4: Uncertainty, Probability Calibration & Abstention (Phase 6)
Fits Temperature Scaling parameter $T^*$ on validation logits, computes pre/post Expected Calibration Error (ECE) and Brier scores, plots reliability diagrams, and evaluates the risk-coverage selective prediction curve:
```bash
python scripts/calibrate_and_abstain.py --config experiments/configs/mobilenet_v2.yaml
python scripts/calibrate_and_abstain.py --config experiments/configs/efficientnet_b0.yaml
python scripts/calibrate_and_abstain.py --config experiments/configs/resnet50.yaml
```

### Step 5: Interpretability via Grad-CAM (Phase 7)
Generates gradient activation heatmaps at the penultimate convolutional layers (`Conv_1`, `top_conv`, `conv5_block3_out`) on True Positives, False Positives, and False Negatives:
```bash
python scripts/gradcam_analysis.py --config experiments/configs/mobilenet_v2.yaml
python scripts/gradcam_analysis.py --config experiments/configs/efficientnet_b0.yaml
python scripts/gradcam_analysis.py --config experiments/configs/resnet50.yaml
```

### Step 6: Ablation Studies (Phase 8)
Evaluates specific architectural and optimization hypotheses:
```bash
# Ablation A: Completely Frozen Backbone vs Fine-Tuned
python scripts/train_vision_benchmark.py --config experiments/configs/ablation_frozen.yaml
python scripts/evaluate_models.py --config experiments/configs/ablation_frozen.yaml

# Ablation B: Input Resolution (160x160 vs 224x224)
python scripts/train_vision_benchmark.py --config experiments/configs/ablation_res160.yaml
python scripts/evaluate_models.py --config experiments/configs/ablation_res160.yaml

# Ablation C: Impact of Data Augmentation (No-Aug vs Aug)
python scripts/train_vision_benchmark.py --config experiments/configs/ablation_no_aug.yaml
python scripts/evaluate_models.py --config experiments/configs/ablation_no_aug.yaml
```

### Step 7: Deployment Efficiency & Latency Profiling (Phase 9)
Measures parameter counts, model file sizes, CPU and GPU single-shot and batch inference latencies (over 100 runs), and peak memory usage:
```bash
python scripts/benchmark_efficiency.py
```

### Step 8: Master Compilation of Reports and Registry
Aggregates all JSON metrics and logs into `EXPERIMENT_REGISTRY.csv`, `MODEL_COMPARISON.md`, and `EXTERNAL_VALIDATION_REPORT.md`:
```bash
python scripts/run_all_experiments.py
```

---

## 4. Experiment Tracking with MLflow

All hyperparameter manifests, per-epoch loss/accuracy curves, metrics, and best checkpoints are automatically logged to a local SQLite database:
```bash
mlflow ui --backend-store-uri sqlite:///mlflow.db --port 5000
```
Visit `http://localhost:5000` to inspect the visual runs, compare parameter histories, and download artifacts.

